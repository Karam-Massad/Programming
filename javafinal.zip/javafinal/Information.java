package javafinal;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class Information {

	private JFrame frame;
	private JTextField txtfaname;
	private JTextField txtmname;
	private JTextField txtID;
	private JTextField txtcity;
	private JTextField txtnat;
	private JTextField txtblood;
	private JTextField txtemail;
private String FatherName, MotherName, IDnumber, city, nationality, bloodtype,email;
static String output;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Information window = new Information();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Information() {
		initialize();
	}

	/**
	 * Initialise the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("ministry of tourism");
		frame.getContentPane().setBackground(new Color(102, 153, 102));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		
		JLabel lblMinistryOfTourism = new JLabel("Ministry of tourism");
		lblMinistryOfTourism.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblMinistryOfTourism.setBounds(139, 11, 190, 27);
		frame.getContentPane().add(lblMinistryOfTourism);
		
		JLabel lblFatherName = new JLabel("Father name ");
		lblFatherName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblFatherName.setBounds(10, 92, 95, 14);
		frame.getContentPane().add(lblFatherName);
		
		txtfaname = new JTextField();
		txtfaname.setBounds(103, 91, 86, 20);
		frame.getContentPane().add(txtfaname);
		txtfaname.setColumns(10);
		
		JLabel lblMotherName = new JLabel("Mother name");
		lblMotherName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMotherName.setBounds(225, 92, 105, 14);
		frame.getContentPane().add(lblMotherName);
		
		txtmname = new JTextField();
		txtmname.setBounds(340, 91, 86, 20);
		frame.getContentPane().add(txtmname);
		txtmname.setColumns(10);
		
		JLabel lblIdNumber = new JLabel("ID number");
		lblIdNumber.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblIdNumber.setBounds(10, 172, 95, 14);
		frame.getContentPane().add(lblIdNumber);
		
		txtID = new JTextField();
		txtID.setBounds(103, 171, 139, 20);
		frame.getContentPane().add(txtID);
		txtID.setColumns(10);
		
		JLabel lblCity = new JLabel("City");
		lblCity.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCity.setBounds(10, 117, 46, 22);
		frame.getContentPane().add(lblCity);
		
		txtcity = new JTextField();
		txtcity.setBounds(103, 119, 86, 20);
		frame.getContentPane().add(txtcity);
		txtcity.setColumns(10);
		
		JLabel lblNa = new JLabel("Nationality");
		lblNa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNa.setBounds(235, 117, 69, 20);
		frame.getContentPane().add(lblNa);
		
		txtnat = new JTextField();
		txtnat.setBounds(340, 122, 86, 20);
		frame.getContentPane().add(txtnat);
		txtnat.setColumns(10);
		
		JLabel lblBloodType = new JLabel("Blood type");
		lblBloodType.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBloodType.setBounds(273, 166, 69, 27);
		frame.getContentPane().add(lblBloodType);
		
		txtblood = new JTextField();
		txtblood.setBounds(352, 171, 53, 20);
		frame.getContentPane().add(txtblood);
		txtblood.setColumns(10);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEmail.setBounds(10, 197, 69, 20);
		frame.getContentPane().add(lblEmail);
		
		txtemail = new JTextField();
		txtemail.setBounds(103, 202, 139, 20);
		frame.getContentPane().add(txtemail);
		txtemail.setColumns(10);
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FatherName = txtfaname.getText();
				MotherName = txtmname.getText();
				city = txtcity.getText();
				nationality = txtnat.getText();
				IDnumber = txtID.getText();
				bloodtype = txtblood.getText();
				email = txtemail.getText();
				output = (FatherName) + (",") + (MotherName) + (",") + (city) + (",") + (nationality) + (",") + (IDnumber) + (",") + (bloodtype) + (",") + (email);
				String Output = Information.output;
				try {
					BufferedWriter write = new BufferedWriter(new FileWriter(new File("C:\\source\\javafinal\\javafinal\\src\\javafinal\\New License.txt"), true));
					write.write(Output);
					write.newLine();
					write.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
					Health.main(null);
				
				frame.setVisible(false);
			}
		});
		btnNext.setBounds(337, 227, 89, 23);
		frame.getContentPane().add(btnNext);
	}

}
