package javafinal;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class Renew {

	private JFrame frame;
	private JTextField txtf;
	private JTextField txtl;
	private JTextField txtexp;
	private String firstname2,lastname2, exp;
	static String Output;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Renew window = new Renew();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Renew() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("ministry of tourism");
		frame.getContentPane().setBackground(new Color(102, 153, 102));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		
		JLabel lblMinistryOfTourism = new JLabel("Ministry of tourism");
		lblMinistryOfTourism.setHorizontalAlignment(SwingConstants.CENTER);
		lblMinistryOfTourism.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblMinistryOfTourism.setBounds(109, 0, 228, 34);
		frame.getContentPane().add(lblMinistryOfTourism);
		
		JLabel lblRenewYour = new JLabel("Renew your license ");
		lblRenewYour.setHorizontalAlignment(SwingConstants.CENTER);
		lblRenewYour.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblRenewYour.setBounds(139, 28, 166, 24);
		frame.getContentPane().add(lblRenewYour);
		
		JLabel lblFirstName = new JLabel("First name ");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstName.setBounds(47, 93, 86, 24);
		frame.getContentPane().add(lblFirstName);
		
		txtf = new JTextField();
		txtf.setBounds(119, 97, 86, 20);
		frame.getContentPane().add(txtf);
		txtf.setColumns(10);
		
		JLabel lblLastName = new JLabel("Last name ");
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLastName.setBounds(243, 100, 94, 14);
		frame.getContentPane().add(lblLastName);
		
		txtl = new JTextField();
		txtl.setBounds(317, 97, 86, 20);
		frame.getContentPane().add(txtl);
		txtl.setColumns(10);
		
		JLabel lblLicenseExprationDate = new JLabel("license expration date");
		lblLicenseExprationDate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLicenseExprationDate.setBounds(47, 145, 158, 24);
		frame.getContentPane().add(lblLicenseExprationDate);
		
		txtexp = new JTextField();
		txtexp.setBounds(194, 149, 209, 20);
		frame.getContentPane().add(txtexp);
		txtexp.setColumns(10);
		
		JButton btnNewButton = new JButton("Renew");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstname2 = txtf.getText();
				lastname2 = txtl.getText();
				exp = txtexp.getText();
				Output = (firstname2) + (",") + (lastname2) + (",") + (exp);
				String Output = Renew.Output;
				try {
					BufferedWriter write = new BufferedWriter(new FileWriter(new File("C:\\source\\javafinal\\javafinal\\src\\javafinal\\Renew License.txt"), true));
					write.write(Output);
					write.newLine();
					write.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				Sure.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
	}

}
