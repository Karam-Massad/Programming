package javafinal;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class Health {

	private JFrame frame;
	private JTextField txtexplain;
	private JTextField txthealth;
	private String healthproblems, explain;
	static String Output;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Health window = new Health();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Health() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("ministry of tourism");
		frame.getContentPane().setBackground(new Color(102, 153, 102));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		
		JLabel lblNewLabel = new JLabel("Ministry of toursim");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setBounds(138, 11, 185, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblDoYouHave = new JLabel("Do you have any health problems ?");
		lblDoYouHave.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDoYouHave.setBounds(10, 86, 240, 29);
		frame.getContentPane().add(lblDoYouHave);
		
		JLabel lblIfYesPlease = new JLabel("If yes please explain");
		lblIfYesPlease.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblIfYesPlease.setBounds(20, 126, 191, 29); 
		frame.getContentPane().add(lblIfYesPlease);
		
		txtexplain = new JTextField();
		txtexplain.setBounds(10, 166, 267, 54);
		frame.getContentPane().add(txtexplain);
		txtexplain.setColumns(10);
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				healthproblems = txthealth.getText();
				explain = txtexplain.getText();
				Output = (healthproblems) + (",") + (explain);
				String Output = Health.Output;
				try {
					BufferedWriter write = new BufferedWriter(new FileWriter(new File("C:\\source\\javafinal\\javafinal\\src\\javafinal\\New License.txt"), true));
					write.write(Output);
					write.newLine();
					write.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
				CityOfField.main(null);
				frame.setVisible(false);
			
				
			}
		});
		btnNext.setBounds(325, 227, 89, 23);
		frame.getContentPane().add(btnNext);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setBounds(20, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		txthealth = new JTextField();
		txthealth.setBounds(253, 92, 86, 20);
		frame.getContentPane().add(txthealth);
		txthealth.setColumns(10);
	}

}
