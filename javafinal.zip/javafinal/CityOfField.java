package javafinal;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CityOfField {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CityOfField window = new CityOfField();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CityOfField() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("ministry of tourism");
		frame.getContentPane().setBackground(new Color(102, 153, 102));
		frame.getContentPane().setForeground(new Color(102, 153, 102));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		
		JLabel lblMinistryOfToursim = new JLabel("Ministry of toursim");
		lblMinistryOfToursim.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblMinistryOfToursim.setBounds(136, 11, 181, 29);
		frame.getContentPane().add(lblMinistryOfToursim);
		
		JLabel lblCityOf = new JLabel("City of field ");
		lblCityOf.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCityOf.setBounds(174, 61, 83, 19);
		frame.getContentPane().add(lblCityOf);
		
		JCheckBox chckbxMadaba = new JCheckBox("Madaba");
		chckbxMadaba.setBounds(160, 87, 97, 23);
		frame.getContentPane().add(chckbxMadaba);
		
		JCheckBox chckbxJarash = new JCheckBox("Jarash");
		chckbxJarash.setBounds(160, 113, 97, 23);
		frame.getContentPane().add(chckbxJarash);
		
		JCheckBox chckbxAjloun = new JCheckBox("Ajloun");
		chckbxAjloun.setBounds(160, 139, 97, 23);
		frame.getContentPane().add(chckbxAjloun);
		
		JCheckBox chckbxDeadSea = new JCheckBox("Dead sea");
		chckbxDeadSea.setBounds(160, 165, 97, 23);
		frame.getContentPane().add(chckbxDeadSea);
		
		JCheckBox chckbxOmqais = new JCheckBox("Om-Qais");
		chckbxOmqais.setBounds(160, 191, 97, 23);
		frame.getContentPane().add(chckbxOmqais);
		
		JButton btnNext = new JButton("Register");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.main(null);
				frame.setVisible(false);
			}
		});
		btnNext.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnNext);
	}
}
