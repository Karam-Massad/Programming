package javafinal;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;


public class GetNewLicense {

	private JFrame frame;
	private JTextField txtFname;
	private JTextField txtLname;
	private JTextField txtAge;
	private JTextField txtGender;
	private String FirstName, LastName, Age, Gender;
	static String Output;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GetNewLicense window = new GetNewLicense();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GetNewLicense() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("ministry of tourism");
		frame.getContentPane().setBackground(new Color(102, 153, 102));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		
		JLabel lblGetANew = new JLabel("Get a new license");
		lblGetANew.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblGetANew.setBounds(139, 0, 177, 29);
		frame.getContentPane().add(lblGetANew);
		
		JLabel lblFirstName = new JLabel("First name ");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblFirstName.setBounds(94, 81, 87, 14);
		frame.getContentPane().add(lblFirstName);
		
		txtFname = new JTextField();
		txtFname.setBounds(197, 80, 86, 20);
		frame.getContentPane().add(txtFname);
		txtFname.setColumns(10);
		
		JLabel lblLastName = new JLabel("Last name ");
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblLastName.setBounds(94, 123, 74, 14);
		frame.getContentPane().add(lblLastName);
		
		txtLname = new JTextField();
		txtLname.setBounds(197, 122, 86, 20);
		frame.getContentPane().add(txtLname);
		txtLname.setColumns(10);
		
		JLabel lblAge = new JLabel("Age");
		lblAge.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAge.setBounds(25, 184, 54, 29);
		frame.getContentPane().add(lblAge);
		
		txtAge = new JTextField();
		txtAge.setBounds(69, 190, 86, 20);
		frame.getContentPane().add(txtAge);
		txtAge.setColumns(10);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FirstName = txtFname.getText();
				LastName = txtLname.getText();
				Age = txtAge.getText();
				Gender = txtGender.getText();
				Output = (FirstName) + (",") + (LastName) + (",") + (Age) + (",") + (Gender);
				String Output = GetNewLicense.Output;
				try {
					BufferedWriter write = new BufferedWriter(new FileWriter(new File("C:\\source\\javafinal\\javafinal\\src\\javafinal\\New License.txt"), true));
					write.write(Output);
					write.newLine();
					write.close();
				} catch (Exception e2) {
					// TODO: handle exception
				}
				Information.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(339, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblGender.setBounds(253, 199, 86, 14);
		frame.getContentPane().add(lblGender);
		
		txtGender = new JTextField();
		txtGender.setBounds(309, 198, 86, 20);
		frame.getContentPane().add(txtGender);
		txtGender.setColumns(10);
	}
}
